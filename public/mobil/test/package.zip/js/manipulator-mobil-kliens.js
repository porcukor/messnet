jQuery(function($){
	"use strict";

	var socket = io.connect('http://node.dyndns.org:3456');

	var messages = [];

	var app = {
		init: function(){
			this.actions();
			this.socketActions();
		},
    
		SendClientMsg: function(message) {
			socket.emit('ClientMsg', { text: message, id: socket.socket.sessionid});
		},
    
		actions: function(){

		// Chat events
			$('#chat-input-button').click(function(e) {
				var message=$('#chat-input-field').val();
				app.SendClientMsg(message);
				$('#chat-input-field').val('');
				e.preventDefault;
				alert("megnyomtál!");
				return false;
			});
      
			$('#chat-input-field').keypress(function(event) {
				if (event.which == 13) {
				  var message=$('#chat-input-field').val();
				  app.SendClientMsg(message);
				  	$('#chat-input-field').val('');
				}
			});
   
		},

		socketActions: function(){
			socket.on('ServerMsg', function(data){
				app.updateMessages(data);
			});
		},

    	updateMessages: function (data) {
        	if(data) {
            	messages.push(data);
            	var html = '';
            	for(var i=0; i<messages.length; i++) {
                	html += '<b>' + (messages[i].name ? messages[i].name : 'Server') + ': </b>';
                	html += messages[i].text + '<br />';
            	}
            	$('#messages').html(html);
        	} else {
            	console.log("There is a problem:", data);
        	}
    	}
	};
	window.App = app.init();
});


 